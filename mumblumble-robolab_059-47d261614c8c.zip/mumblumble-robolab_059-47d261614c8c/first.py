import ev3dev.ev3 as ev3
import time
motor_left = ev3.LargeMotor('outB')
motor_right = ev3.LargeMotor('outD')

def walk(tim):
    motor_left.duty_cycle_sp = 20
    motor_right.duty_cycle_sp = 20

    motor_left.command = 'run-direct';motor_right.command = 'run-direct'
    time.sleep(tim)
    motor_left.stop();motor_right.stop()

    motor_left.duty_cycle_sp = -20
    motor_right.duty_cycle_sp = -20

    motor_left.command = 'run-direct';motor_right.command = 'run-direct'
    time.sleep(tim)
    motor_left.stop();motor_right.stop()

def main():
    walk(3)

if __name__ == '__main__':
    main()
