import ev3dev.ev3 as ev3

motor_left = ev3.LargeMotor('outB')
motor_right = ev3.LargeMotor('outD')
cs = ev3.ColorSensor()
cs.mode = 'COL-COLOR'
motor_left.duty_cycle_sp = 20
motor_right.duty_cycle_sp = 20

def linefollow():
    motor_left.command = 'run-direct';motor_right.command = 'run-direct'
    while True:
        if cs.value() is 1:   # schwarz
            motor_left.duty_cycle_sp = 20
            motor_right.duty_cycle_sp = 10
        elif cs.value() is 6: #white
            motor_left.duty_cycle_sp = 10
            motor_right.duty_cycle_sp = 20
        elif cs.value() is 5: break
    motor_left.stop();motor_right.stop()

def main():
    linefollow()

if __name__ == '__main__':
    main()
